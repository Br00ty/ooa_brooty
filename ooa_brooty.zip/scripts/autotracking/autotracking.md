# Autotracking

PopTracker implements multiple autotracking interfaces (currently SNES, AP and UAT).

This example currently shows off the SNES and AP interfaces.

For more info check here: https://github.com/black-sliver/PopTracker/blob/master/doc/AUTOTRACKING.md#poptracker-auto-tracking